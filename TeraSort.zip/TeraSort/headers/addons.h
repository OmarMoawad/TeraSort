#ifndef ADDONS_H
#define ADDONS_H

#include "includes.h"
#include "TeraSortItem.h"

uint64_t random (uint64_t size);  //returns a random number


#endif
